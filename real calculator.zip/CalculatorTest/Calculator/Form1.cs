﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calculation;

namespace Calculator
{
    public partial class Form1 : Form
    {
        // Calculator state variables
        private decimal _firstValue = 0m;
        private string _op = null;
        private bool _newEntry = true;
        private Calculation.Calculation _calculator = new Calculation.Calculation(); // Create an instance of Calculator

        public Form1()
        {
            InitializeComponent();
            this.Text = "CM Calculator";
            textBox1.Text = "0";
        }

        // Helper method to append digits to the text box
        private void AppendDigit(string d)
        {
            if (_newEntry || textBox1.Text == "0")
            {
                textBox1.Text = d;
                _newEntry = false;
            }
            else
            {
                textBox1.Text += d;
            }
        }

        // Try to get the current number from the text box
        private bool TryGetCurrent(out decimal val)
        {
            return decimal.TryParse(textBox1.Text, NumberStyles.Number, CultureInfo.CurrentCulture, out val);
        }

        // Set the operation (+, -, *, /)
        private void SetOp(string op)
        {
            if (TryGetCurrent(out var cur))
            {
                if (_op == null)
                {
                    _firstValue = cur;
                }
                else if (!_newEntry)
                {
                    // Chain operations
                    _firstValue = Compute(_firstValue, cur, _op);
                    textBox1.Text = _firstValue.ToString(CultureInfo.CurrentCulture);
                }
            }
            _op = op;
            _newEntry = true;
        }

        // Perform the actual computation
        private decimal Compute(decimal a, decimal b, string op)
        {
            switch (op)
            {
                case "+":
                    return _calculator.Add(a, b);
                case "-":
                    return _calculator.Subtract(a, b);
                case "*":
                    return _calculator.Multiply(a, b);
                case "/":
                    return _calculator.Divide(a, b);
                default: return b;
            }
        }

        // Clear all calculator state
        private void ClearAll()
        {
            _firstValue = 0m;
            _op = null;
            _newEntry = true;
            textBox1.Text = "0";
        }

        // Handle backspace action
        private void Backspace()
        {
            if (_newEntry) return;
            if (textBox1.Text.Length <= 1)
                textBox1.Text = "0";
            else
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
        }

        // Button handlers for the calculator
        private void btnClear_Click(object sender, EventArgs e) => ClearAll();
        private void btnBackspace_Click(object sender, EventArgs e) => Backspace();

        private void btn0_Click(object sender, EventArgs e) => AppendDigit("0");
        private void btn1_Click(object sender, EventArgs e) => AppendDigit("1");
        private void btn2_Click(object sender, EventArgs e) => AppendDigit("2");
        private void btn3_Click(object sender, EventArgs e) => AppendDigit("3");
        private void btn4_Click(object sender, EventArgs e) => AppendDigit("4");
        private void btn5_Click(object sender, EventArgs e) => AppendDigit("5");
        private void btn6_Click(object sender, EventArgs e) => AppendDigit("6");
        private void btn7_Click(object sender, EventArgs e) => AppendDigit("7");
        private void btn8_Click(object sender, EventArgs e) => AppendDigit("8");
        private void btn9_Click(object sender, EventArgs e) => AppendDigit("9");

        private void btnPlus_Click(object sender, EventArgs e) => SetOp("+");
        private void btnMinus_Click(object sender, EventArgs e) => SetOp("-");
        private void btnMul_Click(object sender, EventArgs e) => SetOp("*");
        private void btnDiv_Click(object sender, EventArgs e) => SetOp("/");

        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (!TryGetCurrent(out var cur)) return;

            if (_op != null)
            {
                var result = Compute(_firstValue, cur, _op);
                textBox1.Text = result.ToString(CultureInfo.CurrentCulture);
                _firstValue = result;
                _op = null;
                _newEntry = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e) { }

        private void Form1_Load(object sender, EventArgs e) { }
    }
}